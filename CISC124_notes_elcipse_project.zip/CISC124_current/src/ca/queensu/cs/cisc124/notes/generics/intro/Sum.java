package ca.queensu.cs.cisc124.notes.generics.intro;

/**
 * Utility class illustrating the need to cast popped elements to the
 * correct type when using a stack-of-{@code Object} implementation.
 *
 */
public class Sum {
    
    /**
     * Returns the sum of the elements in a stack of int (or byte, char, short) or
     * zero if the stack is empty. Removes all elements from the specified stack.
     *
     * @param intStack a stack of Integer
     * @return the sum of the elements in the stack
     * @throws ClassCastException if the stack contains non-Integer references
     */
    public static int sumAndClear(ListObjectStack intStack) {
        int sum = 0;
        while (intStack.size() > 0) {
            Object elem = intStack.pop();
            sum += (Integer) elem;      // cast needed because pop returns an Object reference
        }
        return sum;
    }
    
    public static void main(String[] args) {
    	ListObjectStack s = new ListObjectStack();
    	s.push(1);
    	s.push("hello");
    	s.push(2);
    	System.out.println(Sum.sumAndClear(s));
    }
}