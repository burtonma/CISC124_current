package ca.queensu.cs.cisc124.notes.utilityclasses;

/**
 * Utility class containing methods that operate on {@code String} instances.
 *
 */
public class Strings {

	/**
	 * Returns the Hamming distance between two strings.
	 * 
	 * @param s a string
	 * @param t a string
	 * @return the Hamming distance between the two strings
	 * @throws NullPointerException     if s or t is null
	 * @throws IllegalArgumentException if s and t have different lengths
	 */
	public static int hammingDistance(String s, String t) {
		if (s == null || t == null) {
			throw new NullPointerException();
		}
		if (s.length() != t.length()) {
			throw new IllegalArgumentException("strings of different lengths: " + s.length() + " and " + t.length());
		}
		int dist = 0;
		for (int i = 0; i < s.length(); i++) {
			char cs = s.charAt(i);
			char ct = t.charAt(i);
			if (cs != ct) {
				dist++;
			}
		}
		return dist;
	}

	/**
	 * Returns {@code true} if {@code s} is a palindrome, {@code false} otherwise. A
	 * string is a palindrome if it is equal to the reversal of itself.
	 * 
	 * @param s a string
	 * @return true if s is a palindrom, false otherwise
	 */
	public static boolean isPalindrome(String s) {
		return s.equals(Strings.reverse(s));
	}

	/**
	 * Returns a new string equal to {@code c} repeated {@code n} times. Returns an
	 * empty string if {@code n <= 0}.
	 * 
	 * @param c a character to repeat
	 * @param n the number of times to repeat the character
	 * @return a new string equal to repeated n times
	 */
	public static String repeat(char c, int n) {
		StringBuilder b = new StringBuilder();
		if (n <= 0) {
			return b.toString();
		}
		for (int i = 0; i < n; i++) {
			b.append(c);
		}
		return b.toString();
	}

	/**
	 * Returns a new string having the characters of {@code s} in reverse order.
	 * Returns the empty string if {@code s == null} is {@code true}.
	 * 
	 * @param s a string
	 * @return a new string having the characters of s in reverse order
	 */
	public static String reverse(String s) {
		if (s == null) {
			s = "";
		}
		StringBuilder b = new StringBuilder(s);
		b.reverse();
		return b.toString();
	}
}
