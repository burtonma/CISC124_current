package ca.queensu.cs.cisc124.notes.interfaces;

import java.lang.Iterable;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * An immutable sequence of integer values having a starting and stopping value.
 * The stopping value is not considered part of the range. An empty range has
 * the same start and stop values.
 *
 */
public class Range implements Iterable<Integer> {
    private int start;
    private int stop;
    
    /**
     * Initialize a range starting at 0 having the specified stopping value.
     * 
     * @param stop the value 1 past the last value in the range
     */
    public Range(int stop) {
        this(0, stop);
    }
    
    /**
     * Initialize a range starting and stopping at the specified values.
     * 
     * @param start the start of the range
     * @param stop the value 1 past the last value in the range
     * @throws IllegalArgumentException if stop is less than start
     */
    public Range(int start, int stop) {
        if (stop < start) {
            String err = String.format("stop: %d is less than start: %d", stop, start);
            throw new IllegalArgumentException(err);
        }
        this.start = start;
        this.stop = stop;
    }
    
    /**
     * Returns an iterator over this range starting at the start value of this range.
     * 
     * @return an iterator over this range starting at the start value of this range
     */
    @Override
    public Iterator<Integer> iterator() {
        return new RangeIterator();
    }
    
    /**
     * An iterator over a range. The iterator starts at the starting value of the range
     * and goes up to, but not including, the maximum value of the range.
     */
    private class RangeIterator implements Iterator<Integer> {
        // the value returned by next
        private int val;
        
        // starting counting from the starting value of the enclosing Range object
        RangeIterator() {
            this.val = Range.this.start;
        }
        
        // returns true if this.val is less than the stopping value of the enclosing Range object
        @Override
        public boolean hasNext() {
            return this.val < Range.this.stop;
        }
        
        // returns the current value of this.val and then increments this.val
        @Override
        public Integer next() {
            if (!this.hasNext()) {
                throw new NoSuchElementException("no more elements in range");
            }
            Integer result = this.val;
            this.val++;
            return result;
        }
    }
    
    
    public static void main(String[] args) {
    	for (int i : new Range(0, 10)) {
    	    System.out.println(i);
    	}
    }
}