package ca.queensu.cs.cisc124.notes.turtle;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ca.queensu.cs.cisc124.notes.basics.geometry.Point2;

public class KochSnowflake {

	private static void drawKochSnowflake(List<Turtle> turtles) {

		drawKoch(turtles, 0.5, 4);
		for (Turtle t : turtles) {
			t.turnRight(120.0);
		}
		drawKoch(turtles, 0.5, 4);
		for (Turtle t : turtles) {
			t.turnRight(120.0);
		}
		drawKoch(turtles, 0.5, 4);
	}

	private static void drawKoch(List<Turtle> turtles, double length, int depth) {
		if (depth == 0) {
			for (Turtle t : turtles) {
				t.forward(length);
			}
		} else {
			length /= 3.0;
			drawKoch(turtles, length, depth - 1);
			for (Turtle t : turtles) {
				t.turnLeft(60.0);
			}
			drawKoch(turtles, length, depth - 1);
			for (Turtle t : turtles) {
				t.turnRight(120.0);
			}
			drawKoch(turtles, length, depth - 1);
			for (Turtle t : turtles) {
				t.turnLeft(60.0);
			}
			drawKoch(turtles, length, depth - 1);
		}
	}

	public static void main(String[] args) {
		List<Color> colors = Arrays.asList(Color.BLUE, Color.CYAN, Color.GREEN, Color.MAGENTA, Color.RED);
		List<Turtle> turtles = new ArrayList<Turtle>();
		Turtle t = new Turtle(new Point2(0.5, 0.5), 0.0, new Pen());
		turtles.add(t);
		for (int i = 0; i < 5; i++) {
			Turtle ti = new Turtle(new Point2(0.5, 0.5), 0.0, new Pen());
			ti.turnLeft(60.0 * (i + 1));
			ti.pen().setColor(colors.get(i));
			turtles.add(ti);
		}
		drawKochSnowflake(turtles);
	}
}