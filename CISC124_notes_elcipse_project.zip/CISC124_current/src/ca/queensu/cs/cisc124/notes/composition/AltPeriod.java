package ca.queensu.cs.cisc124.notes.composition;

import java.time.LocalTime;

/**
 * An alternative implementation of the {@code Period} class that uses 
 * immutable objects.
 *
 */
public class AltPeriod {
    private LocalTime start;
    private LocalTime end;

    /**
     * Initialize the period to the given start and end times.
     * 
     * @param start beginning of the period
     * @param end end of the period; must not precede start
     * @throws IllegalArgumentException if start is after end
     */
    public AltPeriod(LocalTime start, LocalTime end) {
        if (start.compareTo(end) > 0) {
            throw new IllegalArgumentException("start after end");
        }
        this.start = start;
        this.end = end;
    } 

    /**
     * Initialize the period so that it has the same start and end times
     * as the specified period.
     *
     * @param other the period to copy
     */
    public AltPeriod(AltPeriod other) {
        this.start = other.start;
        this.end = other.end;
    } 

    /**
     * Returns the starting time of the period.
     * 
     * @return the starting time of the period
     */
    public LocalTime getStart() {
        return this.start;
    }

    /**
     * Returns the ending time of the period.
     * 
     * @return the ending time of the period
     */
    public LocalTime getEnd() {
        return this.end;
    }

    /**
     * Sets the starting time of the period.
     * 
     * @param newStart the new starting time of the period
     * @return true if the new starting time is earlier than the
     *         current end time; false otherwise
     */
    public boolean setStart(LocalTime newStart) {
        boolean ok = false;
        if (newStart.isBefore(this.end)) {
            this.start = newStart;
            ok = true;
        }
        return ok;
    }

    /**
     * Sets the ending time of the period.
     * 
     * @param newEnd the new ending time of the period
     * @return true if the new ending time is after the
     *         current start time; false otherwise
     */
    public boolean setEnd(LocalTime newEnd) {
        boolean ok = false;
        if (newEnd.isAfter(this.start)) {
            this.end = newEnd;
            ok = true;
        }
        return ok;
    }
    
    /**
     * Extend the duration of this period by the specified number of
     * hours. The period is extended by changing the end time of
     * this period.
     *
     * @param hours the number of hours to extend this period by
     */
    public void extend(int hours) {
        if (hours < 0) {
            throw new IllegalArgumentException();
        }
        this.end = this.end.plusHours(hours);
    }
    
    /**
     * Returns true if the start time of this period is before 
     * the end time of this period.
     *
     * @return true if the class invariant is true
     */
    public boolean isInvariantTrue() {
        return this.start.isBefore(this.end);
    }

    /**
     * Compares this period with an object for equality. The result
     * is true if and only if obj is a Period object having an equal
     * start and end time as this period.
     *
     * @param obj the object to compare
     * @return true if obj is equal to this period
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AltPeriod)) {
            return false;
        }
        AltPeriod other = (AltPeriod) obj;
        return this.start.equals(other.start) && this.end.equals(other.end);
    }
}