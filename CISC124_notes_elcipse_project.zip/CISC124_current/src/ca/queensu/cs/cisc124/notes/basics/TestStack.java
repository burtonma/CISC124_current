package ca.queensu.cs.cisc124.notes.basics;

/**
 *	Small test program for the Stack class.
 */
public class TestStack {

    /**
     * This main method makes a stack and pushes and pops elements
     * onto the stack.
     * 
     * @param args no used
     */
    public static void main(String[] args) {
        Stack t = new Stack();
        t.push("a");
        t.push("b");
        t.push("c");
        System.out.println("size of stack: " + t.size());
        System.out.println(t);
        System.out.println();
        
        String elem = t.pop();
        System.out.println("popped : " + elem);
        System.out.println("size of stack: " + t.size());
        System.out.println(t);
        System.out.println();
        
        elem = t.pop();
        System.out.println("popped : " + elem);
        System.out.println("size of stack: " + t.size());
        System.out.println(t);
        System.out.println();
        
        elem = t.pop();
        System.out.println("popped : " + elem);
        System.out.println("size of stack: " + t.size());
        System.out.println(t);
    }
}
