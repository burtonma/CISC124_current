package ca.queensu.cs.cisc124.notes.basics;

/**
 * The standard hello, world program almost every new programmer learns.
 */
public class HelloWorld {
	
	/**
	 * Every Java program begins at a main method
	 * 
	 * @param args command line arguments; not used here
	 */
	public static void main(String... args) {
        System.out.println("Hello, world!");
    }
}
