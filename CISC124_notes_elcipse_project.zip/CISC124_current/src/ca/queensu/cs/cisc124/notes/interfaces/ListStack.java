package ca.queensu.cs.cisc124.notes.interfaces;

import java.util.ArrayList;

/**
 * An {@code ArrayList}-based implementation of the {@code Stack} interface.
 *
 */
public class ListStack implements Stack {

    private ArrayList<String> stack;
    
    public ListStack() {
        this.stack = new ArrayList<>();
    }

    @Override
    public int size() {
        return this.stack.size();
    }

    @Override
    public void push(String elem) {
        this.stack.add(elem);
    }

    @Override
    public String pop() {
        String elem = this.stack.remove(this.size() - 1);
        return elem;
    }

    /**
     * Returns a string representation of this stack. The elements of the stack
     * appear in the returned string in sequence starting from the top of the
     * stack to the bottom of the stack with each element separated from the
     * next using a newline character.
     * 
     * @return a string representation of this stack
     */
    @Override
    public String toString() {
        StringBuilder b = new StringBuilder("Stack:");
        if (this.size() != 0) {
            for (int i = this.size() - 1; i >= 0; i--) {
                b.append('\n');
                b.append(this.stack.get(i));
            }
        }
        return b.toString();
    }
}