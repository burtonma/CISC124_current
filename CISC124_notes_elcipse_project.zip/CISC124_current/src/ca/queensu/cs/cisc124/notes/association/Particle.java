package ca.queensu.cs.cisc124.notes.association;

import ca.queensu.cs.cisc124.notes.basics.geometry.Point2;
import ca.queensu.cs.cisc124.notes.basics.geometry.Vector2;

/**
 * A very simple class for representing point-like particles having position and
 * velocity in two dimensions.
 * 
 * <p>
 * A particle is an aggregation of a Point2 and Vector2 object.
 */
public class Particle {
	private Point2 position;
	private Vector2 velocity;

	/**
	 * Initialize this particle to have position (0, 0) and velocity (0, 0).
	 */
	public Particle() {
		this.position = new Point2();
		this.velocity = new Vector2();
	}

	/**
	 * Initialize this particle to have the specified position and velocity. It is
	 * assumed that the position and velocity are not {@code null}.
	 * 
	 * @param position the position of this particle
	 * @param velocity the velocity of this particle
	 */
	public Particle(Point2 position, Vector2 velocity) {
		this.position = position;
		this.velocity = velocity;
	}

	/**
	 * Returns the position of this particle.
	 * 
	 * @return the position of this particle.
	 */
	public Point2 position() {
		return this.position;
	}

	/**
	 * Returns the velocity of this particle.
	 * 
	 * @return the velocity of this particle.
	 */
	public Vector2 velocity() {
		return this.velocity;
	}

	/**
	 * Sets the position of this particle to the specified position.
	 * 
	 * @param position the position of this particle
	 * @return the previous position of this particle
	 */
	public Point2 setPosition(Point2 position) {
		Point2 old = this.position;
		this.position = position;
		return old;
	}

	/**
	 * Sets the velocity of this particle to the specified velocity.
	 * 
	 * @param velocity the velocity of this particle
	 * @return the previous velocity of this particle
	 */
	public Vector2 setVelocity(Vector2 velocity) {
		Vector2 old = this.velocity;
		this.velocity = velocity;
		return old;
	}

	/**
	 * Moves this particle to a new position assuming that an amount of time
	 * {@code dt} has elapsed.
	 * 
	 * <p>
	 * The new position is equal to the current position of this particle plus the
	 * vector equal to the velocity of this particle times {@code dt}.
	 * 
	 * @param dt an amount of time
	 * @return a reference to the new position of this particle
	 */
	public Point2 move(double dt) {
		this.position.add(Vector2.multiply(dt, this.velocity));
		return this.position;
	}

	/**
	 * Returns a string representation of this particle. The returned string
	 * contains information about the position and velocity of this particle.
	 * 
	 * @return a string representation of this particle
	 */
	@Override
	public String toString() {
		return "pos.: " + this.position + ", vel.: " + this.velocity;
	}
}