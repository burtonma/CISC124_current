package ca.queensu.cs.cisc124.notes.inheritance.shapes;

/**
 * A shape representing a zero-width vertical line.
 * 
 * <p>
 * THIS IS AN EXAMPLE OF THE INCORRECT USE OF INHERITANCE. The {@code Shape} base class
 * says that shapes have a minimum width and height of one, but a vertical line has
 * a width of zero.
 */
public class VLine extends Shape {
    
    /**
     * Initialize this line to a height of one and width of zero.
     */
    public VLine() {
        super();
        this.width = 0;     // uh, oh, width of zero
    }
    
    /**
     * Returns zero.
     * 
     * @return zero (the width of this line)
     */
    @Override
    public double width() { 
        return 0.0;    // oops, shapes are supposed to have a minimum width of 1
    }
}