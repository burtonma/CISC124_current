package ca.queensu.cs.cisc124.notes.generics.list;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * An array-based implementation of a {@code SList}.
 *
 * @param <E> the type of elements in this list
 */
public class SArrayList<E> implements SList<E> {

	private final int DEFAULT_CAPACITY = 16;
	private Object[] arr;
	private int size;

	/**
	 * Initializes an empty list. 
	 */
	public SArrayList() {
		this.arr = new Object[DEFAULT_CAPACITY];
		this.size = 0;
	}

	@Override
	public int size() {
		return this.size;
	}

	@Override
	public void add(E elem) {
		// do we need to resize the array?
		if (this.size() == this.arr.length) {
			this.arr = Arrays.copyOf(this.arr, this.arr.length * 2);
		}
		this.arr[this.size] = elem;
		this.size++;
	}

	/**
	 * Throws an {@code IndexOutOfBoundsException} if index is less than 0 or
	 * greater than {@code this.size - 1}.
	 * 
	 * @param index an index to validate
	 * @throws {@code IndexOutOfBoundsException} if index is less than 0 or
	 * greater than {@code this.size - 1}
	 */
	private void checkIndex(int index) {
		if (index < 0) {
			throw new IndexOutOfBoundsException("negative index: " + index);
		} else if (index >= this.size) {
			throw new IndexOutOfBoundsException("index out of bounds: " + index + ", size: " + this.size);
		}
	}

	@Override
	public E get(int index) {
		this.checkIndex(index);
		return (E) this.arr[index];
	}

	@Override
	public E set(int index, E elem) {
		// get element at index, this also checks the index
		E old = this.get(index);
		this.arr[index] = elem;
		return old;
	}

	@Override
	public void add(int index, E elem) {
		// index can be equal to this.size
		if (index == this.size) {
			this.add(elem);
			return;
		}
		this.checkIndex(index);

		// move elements at indexes size-1, size-2, ..., index one position to right
		// i is in the index of the element to move to the right
		for (int i = this.size - 1; i >= index; i--) {
			this.arr[i + 1] = this.arr[i];                      // can this throw?
		}
		// insert elem and update size
		this.arr[index] = elem;
		this.size++;
	}

	@Override
	public E remove(int index) {
		// get element at index, this also checks the index
		E removed = this.get(index);
		
		// move elements at indexes index+1, index+2, ..., size-1 one position to left
		// i is in the index of the element to move to the right
		for (int i = index + 1; i < this.size; i++) {
			this.arr[i - 1] = this.arr[i];                      // can this throw?
		}
		// null out old last element and update size
		this.arr[this.size - 1] = null;
		this.size--;
		return removed;
	}
	
	@Override
	public String toString() {
		StringBuilder b = new StringBuilder("[");
		if (!this.isEmpty()) {
			b.append(this.get(0));
			for (int i = 1; i < this.size; i++) {
				b.append(", ");
				b.append(this.get(i));
			}
		}
		b.append("]");
		return b.toString();
	}

	@Override
	public Iterator<E> iterator() {
		return new ArrayIterator();
	}

	private class ArrayIterator implements Iterator<E> {
		/**
         * Index of element to be returned by subsequent call to next.
         */
		private int next;
		
		/**
         * Index of element returned by most recent call to next.
         * Reset to -1 if this element is deleted by a call to remove.
         */
		private int prev;
		
		ArrayIterator() {
			this.next = 0;
			this.prev = -1;
		}
		
		@Override
		public boolean hasNext() {
			return this.next < SArrayList.this.size;
		}
		
		@Override
		public E next() {
			if (!this.hasNext()) {
				throw new NoSuchElementException();
			}
			E e = SArrayList.this.get(this.next);
			this.prev = this.next;
			this.next++;
			return e;
		}
		
		@Override
		public void remove() {
			if (this.prev == -1) {
				throw new IllegalStateException();
			}
			SArrayList.this.remove(this.prev);
			this.next--;
			this.prev = -1;
		}
	}
	
	public static void main(String[] args) {
		SList<Integer> t = new SArrayList<>();
		System.out.println(t);
		t.add(9);
		System.out.println(t);
		t.add(8);
		System.out.println(t);
		t.add(7);
		System.out.println(t);
	}
}
