package ca.queensu.cs.cisc124.notes.interfaces;

/**
 * The function y = x * x.
 *
 */
public class Square implements Function1 {

	@Override
	public double eval(double x) {
		return x * x;
	}

	@Override
	public String toString() {
		return "square";
	}
}
