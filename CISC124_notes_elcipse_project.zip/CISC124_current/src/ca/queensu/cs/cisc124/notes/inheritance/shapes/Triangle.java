package ca.queensu.cs.cisc124.notes.inheritance.shapes;

/**
 * A triangle class that can return its true area.
 *
 */
public class Triangle extends Shape {
    
    /**
     * Initializes this triangle to have a width and height of one.
     */
    public Triangle() {
        super();
    }
    
    /**
     * Returns the true area of this triangle.
     *
     * @return the area of this triangle
     */ 
    @Override
    public double areaUpperBound() {
        return 0.5 * this.width * this.height;
    }

}
