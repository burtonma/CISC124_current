package ca.queensu.cs.cisc124.notes.composition;

import java.util.Date;

/**
 * A period of time where the period has a start time and an end time.
 * The end time is always after the start time.
 *
 * <p>
 * THIS IMPLEMENTATION USES AGGREGATION AND FAILS TO SATISFY ITS
 * CLASS INVARIANT.
 *
 */
public class Period {
    private Date start;
    private Date end;

    /**
     * Initialize the period to the given start and end dates.
     * 
     * @param start beginning of the period
     * @param end end of the period; must not precede start
     * @throws IllegalArgumentException if start is after end
     */
    public Period(Date start, Date end) {
        if (start.compareTo(end) > 0) {
            throw new IllegalArgumentException("start after end");
        }
        this.start = start;
        this.end = end;
    } 

    /**
     * Initialize the period so that it has the same start and end times
     * as the specified period.
     *
     * @param other the period to copy
     */
    public Period(Period other) {
        this.start = other.start;
        this.end = other.end;
    } 

    /**
     * Returns the starting date of the period.
     * 
     * @return the starting date of the period
     */
    public Date getStart() {
        return this.start;
    }

    /**
     * Returns the ending date of the period.
     * 
     * @return the ending date of the period
     */
    public Date getEnd() {
        return this.end;
    }

    /**
     * Sets the starting date of the period.
     * 
     * @param newStart the new starting date of the period
     * @return true if the new starting date is earlier than the
     *         current end date; false otherwise
     */
    public boolean setStart(Date newStart) {
        boolean ok = false;
        if (newStart.compareTo(this.end) < 0) {
            this.start = newStart;
            ok = true;
        }
        return ok;
    }

    /**
     * Sets the ending date of the period.
     * 
     * @param newEnd the new ending date of the period
     * @return true if the new ending date is after the
     *         current start date; false otherwise
     */
    public boolean setEnd(Date newEnd) {
        boolean ok = false;
        if (newEnd.compareTo(this.start) > 0) {
            this.end = newEnd;
            ok = true;
        }
        return ok;
    }
    
    /**
     * Extend the duration of this period by the specified number of
     * hours. The period is extended by changing the end time of
     * this period.
     *
     * @param hours the number of hours to extend this period by
     */
    public void extend(int hours) {
        if (hours < 0) {
            throw new IllegalArgumentException();
        }
        this.end.setHours(this.end.getHours() + hours);
    }
    
    /**
     * Returns true if the start time of this period is before 
     * the end time of this period.
     *
     * @return true if the class invariant is true
     */
    public boolean isInvariantTrue() {
        return this.start.compareTo(this.end) < 0;
    }

    /**
     * Compares this period with an object for equality. The result
     * is true if and only if obj is a Period object having an equal
     * start and end time as this period.
     *
     * @param obj the object to compare
     * @return true if obj is equal to this period
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Period)) {
            return false;
        }
        Period other = (Period) obj;
        return this.start.equals(other.start) && this.end.equals(other.end);
    }
}