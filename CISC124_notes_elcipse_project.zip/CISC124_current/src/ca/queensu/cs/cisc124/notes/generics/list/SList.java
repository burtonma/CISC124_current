package ca.queensu.cs.cisc124.notes.generics.list;

import java.util.Iterator;

/**
 * A simplified list interface. A list represents a finite collection of elements
 * held in a linear sequence.

 * @param <E> the type of elements in this list
 */
public interface SList<E> extends Iterable<E>  {
	
	/**
     * Get the number of elements in the list.
     * 
     * @return the number of elements in the list.
     */
    public int size();
    
    /**
     * Returns {@code true} if this list contains no elements, {@code false} otherwise.
     * 
     * @return {@code true} if this list contains no elements, {@code false} otherwise
     */
    default public boolean isEmpty() {
    	return this.size() == 0;
    }
	
	/**
     * Adds the given element to the end of the list.
     * 
     * @param elem the element to add
     */
	public void add(E elem);
	
	/**
     * Returns the element at the specified position in the list.
     * 
     * @param index index of the element to return
     * @return the element at the specified position
     * @throws IndexOutOfBoundsException if the index is out of the range
     *                                   {@code (index < 0 || index >= size())}
     */
    public E get(int index);
    
    /**
     * Sets the element at the specified position in the list.
     * 
     * @param index index of the element to set
     * @param elem element to be stored at the specified position
     * @return the element previously at the specified position
     * @throws IndexOutOfBoundsException if the index is out of the range
     *                                   {@code (index < 0 || index >= size())}
     */
    public E set(int index, E elem);
    
    /**
     * Inserts an element at the specified index of this list. Shifts the element
     * currently at that position (if any) and any subsequent elements to the right.
     * 
     * @param index the index at which to insert the element
     * @param elem  the element to be inserted
     * @throws IndexOutOfBoundsException if the index is out of the range
     *                                   {@code (index < 0 || index > size())}
     */
    public void add(int index, E elem);
    
    /**
     * Removes the element at the specified index of this list, shifts any
     * subsequent elements to the left (subtracts one to their indices), and returns
     * a reference to the removed element.
     * 
     * @param index the index of the element to remove
     * @return the removed element
     * @throws IndexOutOfBoundsException if the index is out of the range
     *                                   {@code (index < 0 || index >= size())}
     */
    public E remove(int index);
    
    /**
     * Returns an iterator over the elements in this list. The iterator visits
     * the elements of this list in the order that the elements appear in this list.
     * 
     * @return an iterator over the elements in this list
     */
    public Iterator<E> iterator();
}
