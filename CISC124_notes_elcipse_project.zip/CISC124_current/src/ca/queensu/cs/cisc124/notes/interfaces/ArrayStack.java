package ca.queensu.cs.cisc124.notes.interfaces;

import java.util.Arrays;

/**
 * An array-based implementation of the {@code Stack} interface.
 *
 */
public class ArrayStack implements Stack {

    // the initial capacity of the stack
    private static final int DEFAULT_CAPACITY = 16;

    // the array that stores the stack
    private String[] arr;

    // the index of the top of the stack (equal to -1 for an empty stack)
    private int top;

    /**
     * Initialize an empty stack.
     */
    public ArrayStack() {
        this.arr = new String[ArrayStack.DEFAULT_CAPACITY];
        this.top = -1;
    }
    
    @Override
    public int size() {
        return this.top + 1;
    }

    @Override
    public void push(String elem) {
    	// do we need to resize the array?
        if (this.size() == this.arr.length) {
            System.out.println("resizing");                              // remove this line in production code
            this.arr = Arrays.copyOf(this.arr, this.arr.length * 2);
        }
        this.top++;
        this.arr[this.top] = elem;    // will throw an exception if this.top == this.arr.length
    }

    @Override
    public String pop() {
        // is the stack empty?
        if (this.isEmpty()) {
            throw new RuntimeException("popped an empty stack");
        }
        // get the element at the top of the stack as type E
        String element = this.arr[this.top];
        
        // null out the value stored in the array; see explanation below why this should be done
        this.arr[this.top] = null;

        // adjust the top of stack index
        this.top--;

        // return the element that was on the top of the stack
        return element;
    }

    /**
     * Returns a string representation of this stack. The elements of the stack
     * appear in the returned string in sequence starting from the top of the
     * stack to the bottom of the stack with each element separated from the
     * next using a newline character.
     * 
     * @return a string representation of this stack
     */
    @Override
    public String toString() {
        StringBuilder b = new StringBuilder("Stack:");
        if (this.size() != 0) {
            for (int i = this.size() - 1; i >= 0; i--) {
                b.append('\n');
                b.append(this.arr[i]);
            }
        }
        return b.toString();
    }
    
}