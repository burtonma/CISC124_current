package ca.queensu.cs.cisc124.notes.tostring;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

/**
 * A class to represent a six-sided die with arbitrary labels on its faces.
 */
public class LabelledDie {
    List<String> labels;
    int value;   // invariant: this.value >= 0 && this.value < 6
    Random rng;
    
    public LabelledDie(List<String> labels) {
        // assume some input validation of parameter labels here   
        this.labels = new ArrayList<>(labels);
        this.value = 0;
        this.rng = new Random();
    }
    
    public String getCurrentValue() {
        return this.labels.get(this.value);
    }
    
    public String roll() {
        this.value = this.rng.nextInt(6);   // random value between 0 and 5 inclusive
        return this.getCurrentValue();
    }
    
    @Override
    public String toString() {
        this.labels.sort(null);
        return "faces: " + this.labels.toString() + ", value: " + this.getCurrentValue();
    }
    
    public static void main(String[] args) {
    	List<String> labels = new ArrayList<>();
    	labels.add("X");
    	labels.add("J");
    	labels.add("Y");
    	labels.add("R");
    	labels.add("E");
    	labels.add("B");
    	LabelledDie d = new LabelledDie(labels);
    	System.out.println(d.roll());
    	System.out.println(d);
    }
}