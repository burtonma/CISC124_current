package ca.queensu.cs.cisc124.notes.generics.basics;

import static org.junit.Assert.*;

import org.junit.Test;

public class LinkedQueueTest {

	@Test
	public void test01_enqueue() {
		// enqueue to empty queue
		LinkedQueue<String> q = new LinkedQueue<>();
		q.enqueue("first");
		
		assertEquals(1, q.size());
		assertEquals("first", q.front());
		assertEquals("first", q.back());
	}
	
	@Test
	public void test02_enqueue() {
		// enqueue to queue of size 1
		LinkedQueue<String> q = new LinkedQueue<>();
		q.enqueue("first");
		q.enqueue("second");
		
		assertEquals(2, q.size());
		assertEquals("first", q.front());
		assertEquals("second", q.back());
	}
	
	@Test
	public void test03_enqueue() {
		// enqueue to queue of size 2
		LinkedQueue<String> q = new LinkedQueue<>();
		q.enqueue("first");
		q.enqueue("second");
		q.enqueue("third");
		
		assertEquals(3, q.size());
		assertEquals("first", q.front());
		assertEquals("third", q.back());
	}

}
